import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class InsecurePasswordExample {
    public static void main(String[] args) throws SQLException {
        // Hardcoded plain text password (This is insecure!)
        String password = "P@ssw0rd123";

        // Simulating usage of the password (e.g., authentication)
        System.out.println("Connecting to the database with password: " + password);

        // Here you would typically use the password to connect to a database or another service
        Connection conn = DriverManager.getConnection("dbUrl", "username", password);
    }
}
