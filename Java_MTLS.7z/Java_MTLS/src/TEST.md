- Password for certificate is P@ssw0rd, totally secure !
- Secret for certificate is P@ssw0rd, totally secure !

AWS_KEY=AKIAIOSFODNN7EXAMPLE
AWS_SECRET_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
